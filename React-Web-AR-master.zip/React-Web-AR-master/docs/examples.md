## Examples

* [Tango tracking module](../examples/tangoTracking.js)
* [aframe-react bindings](../examples/aframeReact.js)
* [Source type image](../examples/image.js)
* [Source type video](../examples/video.js)
* [Source type webcam](../examples/webcam.js)
* [Multiple independent markers](../examples/marker.js)