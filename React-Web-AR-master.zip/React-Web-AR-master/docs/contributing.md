## Contributing

If you're looking to contribute to the project, below are steps to setup the project.

```
git clone https://github.com/nitin42/React-Web-AR.git
cd React-Web-AR
yarn install
```

**Run the example on the development server at `http://127.0.0.1:8000/`**

```
yarn start
```

**Build the project**

```
yarn build
```

This is just a start and the project is experimental but I appreciate your effort in contributing and expanding this further.

Thanks!
